﻿namespace Semana_12
{
    class Ejercicio15
    {
        //Método principal        char variable con carácter
        static void Main()
        {
        //Llamada al método menú
        menu();    
        }

        //Declaración del método menú
        static void menu()
            {
                Console.WriteLine("Ingrese dos números: ");
                int num1, num2;

                //Validación del primer número
                Console.WriteLine("Primer número: ");
                while (!int.TryParse(Console.ReadLine(), out num1))
                {
                    Console.WriteLine("Por favor, ingrese un número válido para el primer número: ");
                }
                Console.ReadKey();
                Console.WriteLine("-------------------------------------------------");
                //Validación del segundo número

                Console.WriteLine("Segundo número: ");
                while (!int.TryParse(Console.ReadLine(), out num2))
                {
                    Console.WriteLine("Por favor, ingrese un número válido para el segundo número: ");
                }
                Console.ReadKey();

                Console.WriteLine("---------------------------------------------");

                Console.WriteLine("Seleccione una opción");
                Console.WriteLine("a. Sumar");
                Console.WriteLine("b. Multiplicar");
                Console.WriteLine("c. Restar");
                //string opcion = Console.ReadLine();
                Console.WriteLine("---------------------------------------------");
                char opcion = Console.ReadLine().ToLower()[0];
                switch (opcion)
                    {
                        case 'a':
                            Console.WriteLine("El resultado es: "+sumar(num1,num2));
                            Console.ReadKey();
                            break;

                        case 'b':
                            Console.WriteLine("El resultado es: "+multiplicar(num1,num2));
                            Console.ReadKey();
                            break;

                        case 'c':
                            Console.WriteLine("El resultado es: "+restar(num1,num2));
                            Console.ReadKey();
                            break;

                        default:
                            Console.WriteLine("La opción seleccionada no es válida.");

                            break;
                    }    
            }
        //Declaración del método sumar
        public static int sumar(int num1, int num2)
        {
        int resultado = num1 + num2;
        return resultado;
        }
        //Declaración del método multiplicar
         public static int multiplicar(int num1, int num2)
        {
        int resultado = num1 * num2;
        return resultado;
        }
        //Declaración del método restar
         public static int restar(int num1, int num2)
        {
        int resultado = num1 - num2;
        return resultado;
        }
    }
} 