﻿using System;

namespace Arreglo_1
{
    class Ejercicio_1
    {
        //Declaración de arreglo tipo entero sin tamaño especifico
        private int[] numeros_ingresados;


        //Metodo cargar
        public void Cargar()
        {
            //Asignando a arreglo un tamaño
            numeros_ingresados = new int[8];
            for (int i = 0; i < numeros_ingresados.Length; i++)
            {
                Console.WriteLine($"Ingrese el número para la posición {i + 1}");
                numeros_ingresados[i] = int.Parse(Console.ReadLine());
            } 

        }

        //Metodo para mostrar arreglo
        public void Imprimir()
        {
            Console.WriteLine("");
            Console.WriteLine($"Lectura de arreglo en posición: ");
            //Declaración de iteración For
            for (int i = 0; i < 8; i++)
            {
                Console.WriteLine($"{i +1}: {numeros_ingresados[i]}");
            }
            Console.ReadKey();
        }

        //Método para sumar
        public void sumar()
        {
            int resultado_suma = 0;
            for (int i = 0; i < numeros_ingresados.Length; i++)
            {
                resultado_suma = resultado_suma +  numeros_ingresados[i];
            }
            Console.WriteLine($"El resultado de la suma es: {resultado_suma}"); 
        }

        //Método promedio
        public void promedio()
        {
            int resultado_suma = 0;
            for (int i = 0; i < numeros_ingresados.Length; i++)
            {
                resultado_suma = resultado_suma +  numeros_ingresados[i];
            }
            
            Console.WriteLine($"El resultado de la suma es: {(resultado_suma / numeros_ingresados.Length)}"); 
        }

        // Metodo principal
        static void Main()
        {
            Ejercicio_1 Ejercicio_1_ = new Ejercicio_1 ();
            Ejercicio_1_.Cargar();
            Ejercicio_1_.Imprimir();
            Ejercicio_1_.sumar();
            Ejercicio_1_.promedio();
        }
    }
}