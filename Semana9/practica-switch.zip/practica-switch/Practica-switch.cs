﻿namespace parcial
{
    class ejercicioSwitch
    {
        static void Main(string[] args)
        {
            string edad_user;
            Console.WriteLine("Por favor ingrese su edad.");
            edad_user = Convert.ToInt32(Console.ReadLine());
            switch (edad_user)
            {
                case {1<=edad_user<= 5}:
                Console.WriteLine($"Usted es de la primera infancia");
                break;

                case {6<= edad_user<= 11}:
                Console.WriteL ine($"Usted es de la infancia");
                break;

                case (12<= edad_user<= 18):
                Console.WriteLine($"Usted es de la adolescencia");
                break;

                case (19<= edad_user<= 25):
                Console.WriteLine($"Usted es de la primera infancia");
                break;

                case (26<= edad_user<= 59):
                Console.WriteLine($"Usted es de la primera infancia");
                break;

                case (edad_user > 60):
                Console.WriteLine($"Usted es de la primera infancia");
                break;
            }
        }
    }
}
