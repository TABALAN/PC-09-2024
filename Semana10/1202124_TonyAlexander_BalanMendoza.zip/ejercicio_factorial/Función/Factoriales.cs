﻿public int CalcularFactorial(int numero)
{
    if (numero == 0)
    {
        return 1;
    }
    else
    {
        int factorial = 1;
        for (int i = 1; i <= numero; i++)
        {
            factorial *= i;
        }
        return factorial;
    }
}