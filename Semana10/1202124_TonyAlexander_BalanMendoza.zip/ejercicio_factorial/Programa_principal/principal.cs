﻿class principal_factorial
{
    static void Main(string [] args)
    {
        int numero; 
        int resultado;
        Console.WriteLine("Hola, por favor ingrese un número para calcular su factorial: ");
        numero = int.Parse(Console.ReadLine());

        //Llamar a la función
        resultado = CalcularFactorial(numero);
        Console.WriteLine($"El factorial de {numero} es: {resultado}");
    }
    static int CalcularFactorial(int numero)
    {
        if (numero == 0)
        {
            return 1;
        }
        else
        {
            int factorial = 1;
            for (int i = 1; i <= numero; i++)
            {
                factorial *= i;
            }
            return factorial;
        }
    }   
}