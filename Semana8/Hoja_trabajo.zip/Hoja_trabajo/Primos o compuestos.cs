﻿namespace Hoja_Trabajo
{
    class primos_compuestos
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola, por favor ingrese un número no mayor de 6 cifras para calcular si es un número primo o compuesto.");
            int num_ingresado = Convert.ToInt32(Console.ReadLine());
            int div = 2;
            bool Primo = true;

            if (num_ingresado < 1000000 && num_ingresado > 0)
            {
                if (num_ingresado == 1 || num_ingresado == 0)
                {
                    Console.WriteLine("El número no es primo y tampoco compuesto.");
                }
                else
                {
                    for (div = 2; div <= num_ingresado / 2; div++)
                    {
                        if (num_ingresado % div == 0)
                        {
                            Primo = false;
                            break;
                        }
                    }

                    if (Primo == true)
                    {
                        Console.WriteLine("El número es primo.");
                    }
                    else
                    {
                        Console.WriteLine("El número es compuesto.");
                    }
                }
            }
            else
            {
                Console.WriteLine("El número ingresado no es permitido."); 
            }
        }
    }
}
